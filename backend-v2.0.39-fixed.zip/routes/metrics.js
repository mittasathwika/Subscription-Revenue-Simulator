const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { getRealMetrics, saveRealMetrics } = require('../models/dynamodb');
const MetricsEngine = require('../utils/metricsEngine');
const { optionalAuth, authenticateToken } = require('../middleware/auth');
const { metricsValidation } = require('../middleware/validator');
const { calculationLimiter } = require('../middleware/rateLimiter');

// GET /api/metrics - Get real metrics for user
router.get('/', optionalAuth, async (req, res) => {
    try {
        const userId = req.headers['x-user-id'] || 'demo@example.com';
        
        const row = await getRealMetrics(userId);
        
        if (!row) {
            // Return default metrics if none exist
            return res.json({
                customers: 100,
                monthly_revenue: 9900,
                churn_rate: 0.05,
                ad_spend: 5000,
                cac: 500,
                source: 'default'
            });
        }
        
        // Calculate derived metrics
        const metrics = {
            customers: row.customers,
            monthly_revenue: row.monthly_revenue,
            churn_rate: row.churn_rate,
            ad_spend: row.ad_spend,
            cac: row.cac,
            arr: row.monthly_revenue * 12,
            arpu: row.monthly_revenue / row.customers,
            ltv: MetricsEngine.calculateLTV(row.monthly_revenue / row.customers, row.churn_rate),
            ltv_cac_ratio: 0,
            payback_period: 0,
            source: 'real_data',
            recorded_at: row.updated_at || row.recorded_at
        };
        
        metrics.ltv_cac_ratio = metrics.ltv / row.cac;
        metrics.payback_period = MetricsEngine.calculatePaybackPeriod(metrics.arpu, row.cac);
        
        res.json(metrics);
    } catch (error) {
        console.error('Error getting metrics:', error);
        res.status(500).json({ error: error.message });
    }
});

// POST /api/metrics/calculate - Calculate projections based on inputs
router.post('/calculate', calculationLimiter, metricsValidation.calculate, async (req, res) => {
    try {
        const inputs = {
            price: parseFloat(req.body.price) || 99,
            churn: parseFloat(req.body.churn) / 100 || 0.05,
            adSpend: parseFloat(req.body.adSpend) || 5000,
            growthRate: parseFloat(req.body.growthRate) / 100 || 0.10,
            initialCustomers: parseInt(req.body.initialCustomers) || 100,
            cac: parseFloat(req.body.cac) || 500,
            months: parseInt(req.body.months) || 12
        };
        
        // Validate inputs
        const errors = [];
        if (inputs.price <= 0) errors.push('Price must be greater than 0');
        if (inputs.churn < 0 || inputs.churn > 1) errors.push('Churn rate must be between 0% and 100%');
        if (inputs.adSpend < 0) errors.push('Ad spend cannot be negative');
        if (inputs.growthRate < 0) errors.push('Growth rate cannot be negative');
        if (inputs.initialCustomers < 0) errors.push('Initial customers cannot be negative');
        if (inputs.cac <= 0) errors.push('CAC must be greater than 0');
        
        if (errors.length > 0) {
            return res.status(400).json({ errors });
        }
        
        // Calculate projections using the metrics engine
        const projection = MetricsEngine.calculateProjections(inputs);
        
        res.json({
            inputs: req.body,
            projection,
            summary: {
                final_customers: projection.customers[projection.customers.length - 1],
                final_revenue: projection.revenue[projection.revenue.length - 1],
                total_revenue: projection.revenue.reduce((a, b) => a + b, 0),
                avg_monthly_growth: ((projection.customers[projection.customers.length - 1] - inputs.initialCustomers) / inputs.initialCustomers / inputs.months * 100).toFixed(1) + '%'
            }
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// POST /api/metrics/real - Update real metrics (protected route)
router.post('/real', authenticateToken, metricsValidation.updateReal, async (req, res) => {
    try {
        const userId = req.headers['x-user-id'] || 'demo@example.com';
        
        const { customers, monthly_revenue, churn_rate, ad_spend, cac } = req.body;
        
        await saveRealMetrics(userId, {
            customers,
            monthly_revenue,
            churn_rate,
            ad_spend,
            cac
        });
        
        res.json({ 
            success: true, 
            message: 'Real metrics updated successfully'
        });
    } catch (error) {
        console.error('Error saving metrics:', error);
        res.status(500).json({ error: error.message });
    }
});

// GET /api/metrics/compare - Compare real vs simulated data
router.get('/compare', optionalAuth, async (req, res) => {
    try {
        const userId = req.headers['x-user-id'] || 'demo@example.com';
        
        const realData = await getRealMetrics(userId);
        
        if (!realData) {
            return res.status(404).json({ error: 'No real data found' });
        }
        
        // Generate simulated projection based on real data
        const inputs = {
            price: realData.monthly_revenue / realData.customers,
            churn: realData.churn_rate,
            adSpend: realData.ad_spend,
            growthRate: 0.10, // Default growth assumption
            initialCustomers: realData.customers,
            cac: realData.cac,
            months: 12
        };
        
        const simulated = MetricsEngine.calculateProjections(inputs);
        
        res.json({
            real: {
                customers: realData.customers,
                monthly_revenue: realData.monthly_revenue,
                arr: realData.monthly_revenue * 12,
                churn_rate: realData.churn_rate,
                recorded_at: realData.updated_at || realData.recorded_at
            },
            simulated: {
                projection: simulated,
                summary: {
                    projected_arr_12mo: simulated.revenue[11] * 12,
                    customer_growth: ((simulated.customers[11] - realData.customers) / realData.customers * 100).toFixed(1) + '%'
                }
            },
            comparison: {
                revenue_difference: simulated.revenue[11] * 12 - (realData.monthly_revenue * 12),
                customer_difference: simulated.customers[11] - realData.customers
            }
        });
    } catch (error) {
        console.error('Error comparing metrics:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
