const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, GetCommand, ScanCommand, UpdateCommand, DeleteCommand } = require('@aws-sdk/lib-dynamodb');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');

// Check if DynamoDB is enabled
const useDynamoDB = process.env.USE_DYNAMODB === 'true';

// DynamoDB client configuration
const client = new DynamoDBClient({
    region: process.env.AWS_REGION || 'us-east-1',
    credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
    }
});

const ddbDocClient = DynamoDBDocumentClient.from(client);

// Table names
const USER_TABLE = process.env.DYNAMODB_USER_TABLE || 'simulator-users';
const METRICS_TABLE = process.env.DYNAMODB_METRICS_TABLE || 'simulator-real-metrics';
const SCENARIOS_TABLE = process.env.DYNAMODB_SCENARIOS_TABLE || 'simulator-scenarios';
const SIMULATIONS_TABLE = process.env.DYNAMODB_SIMULATIONS_TABLE || 'simulator-simulations';

function isDynamoDBEnabled() {
    return useDynamoDB;
}

// User operations
async function createUser(email, password) {
    if (!isDynamoDBEnabled()) return null;
    
    const userId = uuidv4();
    const passwordHash = bcrypt.hashSync(password, 10);
    
    const params = {
        TableName: USER_TABLE,
        Item: {
            id: userId,
            email: email,
            password: passwordHash,
            created_at: new Date().toISOString(),
            last_login: new Date().toISOString()
        }
    };
    
    try {
        await ddbDocClient.send(new PutCommand(params));
        return { id: userId, email: email, password: passwordHash };
    } catch (error) {
        console.error('Error creating user in DynamoDB:', error);
        throw error;
    }
}

async function getUserByEmail(email) {
    if (!isDynamoDBEnabled()) return null;
    
    const params = {
        TableName: USER_TABLE,
        FilterExpression: 'email = :email',
        ExpressionAttributeValues: {
            ':email': email
        }
    };
    
    try {
        const { Items } = await ddbDocClient.send(new ScanCommand(params));
        return Items && Items.length > 0 ? Items[0] : null;
    } catch (error) {
        console.error('Error getting user by email from DynamoDB:', error);
        throw error;
    }
}

async function getUserById(userId) {
    if (!isDynamoDBEnabled()) return null;
    
    const params = {
        TableName: USER_TABLE,
        Key: { id: userId }
    };
    
    try {
        const { Item } = await ddbDocClient.send(new GetCommand(params));
        return Item;
    } catch (error) {
        console.error('Error getting user by ID from DynamoDB:', error);
        throw error;
    }
}

async function updateUserLogin(userId) {
    if (!isDynamoDBEnabled()) return null;
    
    const params = {
        TableName: USER_TABLE,
        Key: { id: userId },
        UpdateExpression: 'SET last_login = :last_login',
        ExpressionAttributeValues: {
            ':last_login': new Date().toISOString()
        }
    };
    
    try {
        await ddbDocClient.send(new UpdateCommand(params));
    } catch (error) {
        console.error('Error updating user login in DynamoDB:', error);
        throw error;
    }
}

// Metrics operations
async function saveRealMetrics(userId, metrics) {
    if (!isDynamoDBEnabled()) return null;
    
    const params = {
        TableName: METRICS_TABLE,
        Item: {
            user_id: userId,
            ...metrics,
            updated_at: new Date().toISOString()
        }
    };
    
    try {
        await ddbDocClient.send(new PutCommand(params));
        return params.Item;
    } catch (error) {
        console.error('Error saving metrics to DynamoDB:', error);
        throw error;
    }
}

async function getRealMetrics(userId) {
    if (!isDynamoDBEnabled()) return null;
    
    const params = {
        TableName: METRICS_TABLE,
        Key: { user_id: userId }
    };
    
    try {
        const { Item } = await ddbDocClient.send(new GetCommand(params));
        return Item;
    } catch (error) {
        console.error('Error getting metrics from DynamoDB:', error);
        throw error;
    }
}

// Scenario operations
async function createScenario(userId, scenario) {
    if (!isDynamoDBEnabled()) return null;
    
    const scenarioId = uuidv4();
    const params = {
        TableName: SCENARIOS_TABLE,
        Item: {
            id: scenarioId,
            user_id: userId,
            ...scenario,
            created_at: new Date().toISOString()
        }
    };
    
    try {
        await ddbDocClient.send(new PutCommand(params));
        return params.Item;
    } catch (error) {
        console.error('Error creating scenario in DynamoDB:', error);
        throw error;
    }
}

async function getScenarios(userId) {
    if (!isDynamoDBEnabled()) return null;
    
    const params = {
        TableName: SCENARIOS_TABLE,
        FilterExpression: 'user_id = :user_id',
        ExpressionAttributeValues: {
            ':user_id': userId
        }
    };
    
    try {
        const { Items } = await ddbDocClient.send(new ScanCommand(params));
        return Items || [];
    } catch (error) {
        console.error('Error getting scenarios from DynamoDB:', error);
        throw error;
    }
}

async function getScenarioById(scenarioId) {
    if (!isDynamoDBEnabled()) return null;
    
    const params = {
        TableName: SCENARIOS_TABLE,
        Key: { id: scenarioId }
    };
    
    try {
        const { Item } = await ddbDocClient.send(new GetCommand(params));
        return Item;
    } catch (error) {
        console.error('Error getting scenario by ID from DynamoDB:', error);
        throw error;
    }
}

async function updateScenario(scenarioId, updates) {
    if (!isDynamoDBEnabled()) return null;
    
    const params = {
        TableName: SCENARIOS_TABLE,
        Key: { id: scenarioId },
        UpdateExpression: 'SET #name = :name, updated_at = :updated_at',
        ExpressionAttributeNames: {
            '#name': 'name'
        },
        ExpressionAttributeValues: {
            ':name': updates.name,
            ':updated_at': new Date().toISOString()
        }
    };
    
    try {
        await ddbDocClient.send(new UpdateCommand(params));
        return { id: scenarioId, ...updates };
    } catch (error) {
        console.error('Error updating scenario in DynamoDB:', error);
        throw error;
    }
}

async function deleteScenario(scenarioId) {
    if (!isDynamoDBEnabled()) return null;
    
    const params = {
        TableName: SCENARIOS_TABLE,
        Key: { id: scenarioId }
    };
    
    try {
        await ddbDocClient.send(new DeleteCommand(params));
        return { id: scenarioId, deleted: true };
    } catch (error) {
        console.error('Error deleting scenario from DynamoDB:', error);
        throw error;
    }
}

// Simulation operations
async function saveSimulationData(userId, data) {
    if (!isDynamoDBEnabled()) return null;
    
    const params = {
        TableName: SIMULATIONS_TABLE,
        Item: {
            user_id: userId,
            ...data,
            updated_at: new Date().toISOString()
        }
    };
    
    try {
        await ddbDocClient.send(new PutCommand(params));
        return params.Item;
    } catch (error) {
        console.error('Error saving simulation to DynamoDB:', error);
        throw error;
    }
}

async function getSimulationData(userId) {
    if (!isDynamoDBEnabled()) return null;
    
    const params = {
        TableName: SIMULATIONS_TABLE,
        Key: { user_id: userId }
    };
    
    try {
        const { Item } = await ddbDocClient.send(new GetCommand(params));
        return Item;
    } catch (error) {
        console.error('Error getting simulation from DynamoDB:', error);
        throw error;
    }
}

// Table initialization (for setup)
async function initializeDynamoDBTables() {
    if (!isDynamoDBEnabled()) {
        console.log('DynamoDB not enabled, skipping table initialization');
        return;
    }
    
    console.log('🚀 DynamoDB mode enabled');
    console.log('🚀 Initializing DynamoDB tables...');
    
    try {
        // Check if tables exist by trying to scan them
        await ddbDocClient.send(new ScanCommand({ TableName: USER_TABLE, Limit: 1 }));
        console.log('✅ Table', USER_TABLE, 'exists');
        
        await ddbDocClient.send(new ScanCommand({ TableName: METRICS_TABLE, Limit: 1 }));
        console.log('✅ Table', METRICS_TABLE, 'exists');
        
        await ddbDocClient.send(new ScanCommand({ TableName: SCENARIOS_TABLE, Limit: 1 }));
        console.log('✅ Table', SCENARIOS_TABLE, 'exists');
        
        await ddbDocClient.send(new ScanCommand({ TableName: SIMULATIONS_TABLE, Limit: 1 }));
        console.log('✅ Table', SIMULATIONS_TABLE, 'exists');
        
        console.log('✅ DynamoDB Tables ready');
    } catch (error) {
        console.error('❌ Error checking DynamoDB tables:', error);
        console.log('⚠️ Please ensure DynamoDB tables are created manually');
    }
}

module.exports = {
    isDynamoDBEnabled,
    initializeDynamoDBTables,
    // User operations
    createUser,
    getUserByEmail,
    getUserById,
    updateUserLogin,
    // Metrics operations
    saveRealMetrics,
    getRealMetrics,
    // Scenario operations
    createScenario,
    getScenarios,
    getScenarioById,
    updateScenario,
    deleteScenario,
    // Simulation operations
    saveSimulationData,
    getSimulationData
};
